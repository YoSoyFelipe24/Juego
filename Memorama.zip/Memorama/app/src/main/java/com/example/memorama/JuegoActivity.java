package com.example.memorama;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Collections;


public class JuegoActivity extends AppCompatActivity {

    private GridLayout gridLayout;
    private Button[] buttons;
    private int[] cardValues;
    private Button firstCard, secondCard;
    private int firstCardIndex, secondCardIndex;
    private boolean isFlipping = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_juego);
        AppCompatImageButton Volver = findViewById(R.id.back);

        Volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(JuegoActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        gridLayout = findViewById(R.id.gridLayout);
        buttons = new Button[16];
        cardValues = new int[16];

        // Crear las cartas con pares de valores (2 veces cada valor)
        ArrayList<Integer> cards = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            cards.add(i);
            cards.add(i);
        }

        // Mezclar las cartas
        Collections.shuffle(cards);

        // Asignar los valores mezclados a las cartas
        for (int i = 0; i < 16; i++) {
            cardValues[i] = cards.get(i);
        }

        // Crear los botones en la cuadrícula
        for (int i = 0; i < 16; i++) {
            final int index = i;
            buttons[i] = new Button(this);
            buttons[i].setText("?");
            buttons[i].setTextSize(18);
            buttons[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!isFlipping) {
                        flipCard(buttons[index], index);
                    }
                }
            });
            gridLayout.addView(buttons[i]);
        }
    }

    private void flipCard(Button button, int index) {
        button.setText(String.valueOf(cardValues[index]));

        if (firstCard == null) {
            // Guardar la primera carta volteada
            firstCard = button;
            firstCardIndex = index;
        } else if (firstCard != null && secondCard == null && firstCard != button) {
            // Guardar la segunda carta volteada
            secondCard = button;
            secondCardIndex = index;

            // Bloquear nuevas interacciones mientras se valida la coincidencia
            isFlipping = true;

            // Verificar si coinciden las cartas
            if (cardValues[firstCardIndex] == cardValues[secondCardIndex]) {
                Toast.makeText(this, "¡Acertaste!", Toast.LENGTH_SHORT).show();
                firstCard.setEnabled(false);
                secondCard.setEnabled(false);
                resetCards();
            } else {
                // No coinciden, voltear las cartas de nuevo después de un pequeño retraso
                gridLayout.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        firstCard.setText("?");
                        secondCard.setText("?");
                        resetCards();
                    }
                }, 1000);
            }
        }
    }

    private void resetCards() {
        firstCard = null;
        secondCard = null;
        isFlipping = false;
    }
}